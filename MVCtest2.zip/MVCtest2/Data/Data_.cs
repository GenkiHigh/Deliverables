﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MVCtest2.Models;

namespace study05Context_study05
{
    public class Data_ : DbContext
    {
        public Data_ (DbContextOptions<Data_> options)
            : base(options)
        {
        }

        public DbSet<MVCtest2.Models.Employee> Employee { get; set; } = default!;
    }
}
