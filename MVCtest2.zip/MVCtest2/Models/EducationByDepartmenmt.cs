﻿//using Microsoft.EntityFrameworkCore;
//using System.ComponentModel.DataAnnotations.Schema;
//using System.ComponentModel.DataAnnotations;
//using System.ComponentModel;

//namespace MVCtest2.Models
//{
//    [Table("education_by_departmenmt")]
//    [PrimaryKey("DepartmentId", "EducationId")]
//    public class EducationByDepartmenmt
//    {
//        [Column("department_code")]
//        [DisplayName("所属コード")]
//        [MaxLength(10)]
//        [Required]
//        public string DepartmentId { get; set; }

//        [Column("education_code")]
//        [DisplayName("教育コード")]
//        [MaxLength(10)]
//        [Required]
//        public string EducationId { get; set; }

//        [Column("education_content")]
//        [DisplayName("教育名称")]
//        [MaxLength(20)]
//        [Required]
//        public string EducationContent { get; set; }
//    }

//}
