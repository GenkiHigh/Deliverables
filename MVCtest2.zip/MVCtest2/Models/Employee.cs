﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using Microsoft.EntityFrameworkCore;

namespace MVCtest2.Models
{
    [Table("employee_master")]
    public class Employee
    {
        [Column("employee_no")]
        [DisplayName("従業員番号")]
        [MaxLength(5)]
        [Required]
        [Key]
        public string EmployeeNo { get; set; }

        [Column("employee_name")]
        [DisplayName("氏名")]
        [MaxLength(20)]
        [Required]
        public string EmployeeName { get; set; }

        [Column("current_address")]
        [DisplayName("住所")]
        [MaxLength(50)]
        [Required]
        public string CurrentAddress { get; set; }

        [Column("birthday")]
        [DisplayName("誕生日")]
        [Required]
        [DataType(DataType.Date)]
        public DateOnly BirthDay { get; set; }

        [Column("age")]
        [DisplayName("年齢")]
        [Range(0, 80)]
        [Required]
        public int Age { get; set; }

        [Column("department_code")]
        [DisplayName("所属コード")]
        [MaxLength(10)]
        [Required]
        public string DepartmentId { get; set; }

        [Column("education_code")]
        [DisplayName("教育コード")]
        [MaxLength(10)]
        public string? EducationId { get; set; }

        public virtual Department? Department { get; set; }
        [Timestamp]
        public uint Version { get; set; }
    }

    [Table("department_master")]
    public class Department
    {
        [Column("department_code")]
        [DisplayName("所属コード")]
        [MaxLength(10)]
        [Required]
        [Key]
        public string DepartmentId { get; set; }

        [Column("department_name")]
        [DisplayName("所属名称")]
        [MaxLength(20)]
        [Required]
        public string DepartmentName { get; set; }

        [Timestamp]
        public uint Version { get; set; }
        public virtual ICollection<Employee>? Employees { get; set; }
    }

    [Table("education_by_departmenmt")]
    [PrimaryKey("DepartmentId", "EducationId")]
    public class EducationByDepartmenmt
    {
        [Column("department_code")]
        [DisplayName("所属コード")]
        [MaxLength(10)]
        [Required]
        [Key]
        public string DepartmentId { get; set; }

        [Column("education_code")]
        [DisplayName("教育コード")]
        [MaxLength(10)]
        [Required]
        [Key]
        public string EducationId { get; set; }

        [Column("education_content")]
        [DisplayName("教育名称")]
        [MaxLength(20)]
        [Required]
        public string EducationContent { get; set; }
    }
}
