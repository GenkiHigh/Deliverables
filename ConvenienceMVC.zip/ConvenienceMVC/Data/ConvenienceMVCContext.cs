﻿using ConvenienceMVC.Models.Entities.Chumons;
using ConvenienceMVC.Models.Entities.Shiires;
using ConvenienceMVC.Models.Entities.UserLogs;
using Microsoft.EntityFrameworkCore;

namespace ConvenienceMVC_Context
{
    public class ConvenienceMVCContext : DbContext
    {
        public ConvenienceMVCContext(DbContextOptions<ConvenienceMVCContext> options)
            : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql("server=localhost;port=5432;username=postgres;database=ConvenienceMVCContext-1e06fd4f-1b99-4241-acde-8ceb0cca7007;password=Genki0317!")
                .EnableSensitiveDataLogging()
                .LogTo(Console.WriteLine, LogLevel.Information);
        }

        // 注文
        public DbSet<ShohinMaster> ShohinMaster { get; set; } = default!;
        public DbSet<ShiireSakiMaster> ShiireSakiMaster { get; set; } = default!;
        public DbSet<ShiireMaster> ShiireMaster { get; set; } = default!;
        public DbSet<ChumonJissekiMeisai> ChumonJissekiMeisai { get; set; } = default!;
        public DbSet<ChumonJisseki> ChumonJisseki { get; set; } = default!;

        // 仕入
        public DbSet<ShiireJisseki> ShiireJisseki { get; set; } = default!;
        public DbSet<SokoZaiko> SokoZaiko { get; set; } = default!;

        // ユーザー情報
        public DbSet<UserLog> UserLog { get; set; } = default!;
    }
}
