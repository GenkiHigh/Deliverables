﻿namespace ConvenienceMVC.Models.Views.UserLogs
{
    // ログイン用ViewModel
    public class UserLoginViewModel
    {
        public string MailAddress { get; set; }

        public string Password { get; set; }
    }
}
