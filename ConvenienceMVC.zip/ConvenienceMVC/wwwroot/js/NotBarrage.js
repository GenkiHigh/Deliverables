$(document).ready(function () {
    $('#notBarrageForm').submit(function () {
        $('#notBarrageButton').prop('disabled', true);
        $(this).submit();
    })
});
//�A�ő΍�
