// iframeの高さ変更
function transIframeHeight(event) {
    if (event.origin !== 'http://localhost:8000' && event.origin !== 'null') {
        return; // 信頼できるオリジンでない場合は処理しない
    }

    var data = JSON.parse(event.data); // メッセージデータをJSON形式でパース
    var iframeId = data.iframeId;
    var iframeHeight = parseInt(data.height); // 高さを整数に変換

    // 対応するiframeの高さを調整する
    var iframe = document.getElementById(iframeId);
    if (iframe) {
        iframe.style.height = iframeHeight + 'px';
    }
}

// 高さを受け取る
function receiveIframeHeight(){
    // 画面サイズ適応
    transIframeHeight('message');

    // iframeからのメッセージを待ち受ける
    window.addEventListener('message', transIframeHeight, false);
}