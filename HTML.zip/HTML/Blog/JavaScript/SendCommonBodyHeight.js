// 高さ送信
function sendIframeHeight(iframeId){
    var bodyHeight = document.body.scrollHeight;
    parent.postMessage(JSON.stringify({ iframeId: iframeId, height: bodyHeight }), '*');
}

// 特定のiframeの高さを送信する
function sendUniqueIframeHeight(iframeId) {
    // 初回送信
    sendIframeHeight(iframeId);
    // ウィンドウのリサイズイベントで再送信
    window.addEventListener('resize', function() {
        sendIframeHeight(iframeId);
    });
}