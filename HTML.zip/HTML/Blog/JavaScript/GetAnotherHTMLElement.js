// 外部HTMLファイルのURLリスト
var externalHTMLURLs = [
    '../Blog/TestBlog1.html',
    '../Blog/TestBlog2.html',
    '../Blog/TestBlog3.html',
    '../Blog/TestBlog4.html'
];
var externalHTMLTags = [
    'title1',
    'title2',
    'title3',
    'title4'
];

function getAnotherHTMLTitle(){
    for(let i = 0;i <externalHTMLURLs.length;i++){
        fetch(externalHTMLURLs[i])
            .then(response => response.text())
            .then(html => {
                // 外部HTMLの<head>要素を取得
                var parser = new DOMParser();
                var doc = parser.parseFromString(html, 'text/html');
                var head = doc.head;
    
                // <title>要素を取得
                var titleElement = head.querySelector('title');
                
                // <title>要素の内容を取得
                var title = titleElement.textContent;
    
                var titleDisplaies = document.getElementsByClassName(externalHTMLTags[i]);
                if(titleDisplaies.length !== 0){
                    for(let i = 0;i < titleDisplaies.length;i++){
                        titleDisplaies[i].innerText = title;
                    }
                }
            })
            .catch(error => console.error('Error fetching external HTML:', error));
    }
};