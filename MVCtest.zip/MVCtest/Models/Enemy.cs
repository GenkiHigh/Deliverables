﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace MVCtest.Models
{
    public class Enemy
    {
        [Column("enemy_no")]
        [DisplayName("敵番号")]
        [MaxLength(5)]
        [Required]
        [Key]
        public string EnemyNo { get; set; }

        [Column("enemy_name")]
        [DisplayName("氏名")]
        [MaxLength(20)]
        [Required]
        public string EnemyName { get; set; }

        [Column("attack")]
        [DisplayName("攻撃力")]
        [Range(0, 10000)]
        [Required]
        public int Attack { get; set; }

        [Column("defence")]
        [DisplayName("防御力")]
        [Range(0, 10000)]
        [Required]
        public int Defence { get; set; }

        [Column("speed")]
        [DisplayName("速度")]
        [Range(0, 10000)]
        [Required]
        public int Speed { get; set; }

        [Column("department")]
        [DisplayName("所属")]
        [MaxLength(20)]
        [Required]
        public string Department { get; set; }
    }
}
