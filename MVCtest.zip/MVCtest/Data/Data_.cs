﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MVCtest.Models;

namespace study05Context_study05
{
    public class Data_ : DbContext
    {
        public Data_ (DbContextOptions<Data_> options)
            : base(options)
        {
        }

        public DbSet<MVCtest.Models.Employee> Employee { get; set; } = default!;

        public DbSet<MVCtest.Models.Enemy> Enemy { get; set; } = default!;
    }
}
